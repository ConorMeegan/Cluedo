
public class Moving {
	
	public Moving()
	{
		//leaving empty for now, possibly will put in moving code later
	}
	
	public int moveUp(int y)
	{
		return y-1;
	}
	
	public int moveDown(int y)
	{
		
		return y+1;
	}
	
	public int moveLeft(int x)
	{
		
		return x+1;
	}
	
	public int moveRight(int x)
	{
		
		return x-1;
	}

}
