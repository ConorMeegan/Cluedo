
public class Start {

	public static void main(String[] args) {
		new Frame(1052,700);

	}

}
